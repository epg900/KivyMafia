#Mafia.py
#-*- coding: utf-8 -*-

from kivy.app import App
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.uix.image import Image
import random
import time
import glob

cardlist=["pedarkhande","zodiac","capo","endcards"]

class Scr1(GridLayout):
   def __init__(self):
     super().__init__()
     self.cols=1
     
     for i in cardlist:
     	self.btn= Button(text=i,background_color =(0.2,0.9, 1, 1),font_size=50)
     	self.btn.bind(on_press=self.callback)
     	self.add_widget(self.btn)
  
   def callback(self,instance):
     	self.lst =glob.glob(f"{instance.text}/*.jpg")
     	self.length=len(self.lst)
     	random.shuffle(self.lst)
     	self.j = 0
     	self.btn2=Button(background_normal=self.lst[self.j])
     	self.btn2.bind(on_press=self.call2)
     	self.popup=Popup(title='',content=self.btn2)
     	self.popup.open()
     
   def call2(self,instance):
     	if self.j<self.length-1:
     		self.j+=1
     	else:
     		self.popup.dismiss()
     	instance.background_normal=self.lst[self.j]
     	
class MyApp(App):
   def build(self):
   	return Scr1()
	 

if __name__ == '__main__':
    MyApp().run()	
