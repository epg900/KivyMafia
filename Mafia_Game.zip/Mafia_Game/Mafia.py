#Mafia.py
#-*- coding: utf-8 -*-
#super(Scr1, self).__init__()
#files = [f for f in os.listdir('.') if re.match(r'[0-9]+.*\.jpg', f)]

from kivy.app import App
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.uix.image import Image
import random
import arabic_reshaper
import bidi.algorithm
import time
import glob

cards= 1
cardlist=["pedarkhande","zodiac","capo","endcards"]
textlist=["mafia"]
sel = 3

if cards:
	senario = cardlist[sel]
else:
	senario = textlist[sel]

class Scr1(GridLayout):
   def __init__(self):
     super().__init__()
     self.cols=2
     if cards:
     	self.lst = glob.glob(f"{senario}/*.jpg")
     else:
     	file=open(f"{senario}.txt","r",encoding="utf-8")
     	self.lst= file.readlines()
     	file.close()
     
     random.shuffle(self.lst)	
     a=len(self.lst)
     for i in range(0,a):
     	 self.btn= Button(text=str(i+1),background_color =(0.2,0.9, 1, 1),font_name='BTitr.ttf',font_size=50)
     	 self.btn.bind(on_press=self.callback)
     	 self.add_widget(self.btn)
  
   def callback(self,instance):
     
     try:
      role=self.lst[int(instance.text)-1]
      txt=arabic_reshaper.reshape(role)
      txt2=bidi.algorithm.get_display(txt)
      if cards:
      	self.popup=Popup(title='',content=Button(background_normal=role, on_press = lambda *args: self.popup.dismiss()))
      else:
      	self.popup=Popup(title='',content=Button(text=txt2,font_name='BTitr.ttf',font_size=50,base_direction='rtl' , on_press = lambda *args: self.popup.dismiss()))
      self.popup.open()
      #time.sleep(8)
      #popup.dismiss()
      instance.disabled=True
     		
     except:
     	pass

class MyApp(App):
   def build(self):
   	return Scr1()
	 

if __name__ == '__main__':
    MyApp().run()	
